#ifndef XFUNC_H
#define XFUNC_H

#include <X11/extensions/XTest.h>
#include <X11/Xlib.h>
#include <X11/keysymdef.h>

void sendKey(unsigned long k);

#endif // XFUNC_H
